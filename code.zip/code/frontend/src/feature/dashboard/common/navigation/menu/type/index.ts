export interface MenuType {
    setOpenDrawer : () => void
}