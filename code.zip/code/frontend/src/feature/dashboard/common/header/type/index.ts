export interface HeaderType {
    title : string
    description ?: string
}