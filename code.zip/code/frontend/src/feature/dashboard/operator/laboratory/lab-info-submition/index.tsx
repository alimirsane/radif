import React from "react";
import Laboratory from "..";

const LaboratoryInformation = () => {
  return <Laboratory />;
};

export default LaboratoryInformation;
