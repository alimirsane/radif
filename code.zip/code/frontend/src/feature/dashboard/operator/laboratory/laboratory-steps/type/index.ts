export enum StepType {
  LABORATORY = "laboratory",
  DEVICE = "device",
  EXPERIMENT = "experiment",
  PARAMETER = "parameter",
  FORM = "form",
}
