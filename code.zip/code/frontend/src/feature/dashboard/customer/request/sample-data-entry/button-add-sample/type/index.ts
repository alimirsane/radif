export interface AddSampleType {
    click : () => void
}