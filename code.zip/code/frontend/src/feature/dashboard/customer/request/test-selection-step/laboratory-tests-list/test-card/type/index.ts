export interface SpecificationType {
  action: string;
  testSpecification: object;
  deviceSpecification: object;
}
