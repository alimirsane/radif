export interface LaboratorySpecificationType {
  status: string;
  specifications: object;
  description?: string;
}
