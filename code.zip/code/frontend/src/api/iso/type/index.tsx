export interface IsoType {
  is_visible_iso: boolean;
  majority_is_visible_iso: string;
}
