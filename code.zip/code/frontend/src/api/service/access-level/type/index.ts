export interface AccessLevelType {
    id : string
    name : string
}