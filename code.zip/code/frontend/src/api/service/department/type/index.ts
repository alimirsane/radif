export interface DepartmentType {
  id: number;
  name: string;
  description: string;
}
