export interface EducationalFieldType {
    id : number,
    name : string,
    order : number
}