export interface EducationalLevelType {
    id : number,
    name : string,
    order : number
}