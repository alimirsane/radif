export interface RequestButtonAction {
  description?: string;
  action?: string;
  value?: string;
}
