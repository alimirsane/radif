export enum GrantStatusType {
  SENT = "sent",
  SEEN = "seen",
  APPROVED = "approved",
  REJECTED = "rejected",
  FAILED = "failed",
  CANCELED = "canceled",
}
