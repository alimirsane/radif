export interface RequestOtpType {
  phone_number: string;
}
