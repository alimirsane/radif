export interface ResultType {
  file?: string | File;
  description: string;
  request: number;
}
