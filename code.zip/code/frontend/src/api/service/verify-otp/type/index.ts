export interface VerifyOtpType {
  phone_number: string;
  otp_code: string;
  new_password: string;
}
