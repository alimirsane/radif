export interface ReportType {
  url: string;
}
