export interface LabDepartmentType {
  id: number;
  name: string;
  description: string;
}
