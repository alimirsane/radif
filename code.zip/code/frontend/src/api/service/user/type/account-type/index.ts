export enum AccountType {
  PERSONAL = "personal",
  BUSINESS = "business",
}
