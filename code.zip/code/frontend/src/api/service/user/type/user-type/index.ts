export enum UserType {
  STAFF = "staff",
  CUSTOMER = "customer",
}
