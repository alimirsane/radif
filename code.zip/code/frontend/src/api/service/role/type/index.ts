export interface RoleType {
    id : number
    name : "admin" | "manager" | "expert" | string
}