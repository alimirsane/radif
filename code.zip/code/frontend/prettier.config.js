module.exports = {
  plugins: ["prettier-plugin-tailwindcss"],
  semi: true,
  tabWidth: 2,
};
